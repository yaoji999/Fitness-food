
from flask import Flask, request, render_template
import os

app = Flask(__name__)

def generer_plan(age, poids, objectif, contexte):
    return f"Objectif : {objectif}\n\nProgramme :\n- 3 séances par semaine (Full body)\n- Cardio 2x/semaine\n- Alimentation : 2000 kcal, riche en protéines\n\nConseil : reste constant 4 semaines et ajuste."

@app.route("/", methods=["GET", "POST"])
def index():
    response = ""
    if request.method == "POST":
        age = request.form["age"]
        poids = request.form["poids"]
        objectif = request.form["objectif"]
        contexte = request.form["contexte"]
        response = generer_plan(age, poids, objectif, contexte)
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
